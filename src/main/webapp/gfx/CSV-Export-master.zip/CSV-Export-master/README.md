# CSV-Export
A small javascript library to handle saving JSON data as a CSV file
